/*
 * app_mfshield.h
 *
 *  Created on: Jun 15, 2022
 *      Author: gosor
 */

#ifndef INC_APP_MFSHIELD_H_
#define INC_APP_MFSHIELD_H_

#include "main.h"
//#define B1_Pin GPIO_PIN_13
//#define B1_GPIO_Port GPIOC
//#define VR_Pin GPIO_PIN_0
//#define VR_GPIO_Port GPIOA
#define S1_Pin GPIO_PIN_1
#define S1_GPIO_Port GPIOA
//#define USART_TX_Pin GPIO_PIN_2
//#define USART_TX_GPIO_Port GPIOA
//#define USART_RX_Pin GPIO_PIN_3
//#define USART_RX_GPIO_Port GPIOA
#define S2_Pin GPIO_PIN_4
#define S2_GPIO_Port GPIOA
#define D1_Pin GPIO_PIN_5
#define D1_GPIO_Port GPIOA
#define D2_Pin GPIO_PIN_6
#define D2_GPIO_Port GPIOA
#define D3_Pin GPIO_PIN_7
#define D3_GPIO_Port GPIOA
#define S3_Pin GPIO_PIN_0
#define S3_GPIO_Port GPIOB
//#define D8CS_Pin GPIO_PIN_10
//#define D8CS_GPIO_Port GPIOB
//#define D8IN_Pin GPIO_PIN_7
//#define D8IN_GPIO_Port GPIOC
#define SRCLK_Pin GPIO_PIN_8
#define SRCLK_GPIO_Port GPIOA
#define SER_Pin GPIO_PIN_9
#define SER_GPIO_Port GPIOA
//#define TMS_Pin GPIO_PIN_13
//#define TMS_GPIO_Port GPIOA
//#define TCK_Pin GPIO_PIN_14
//#define TCK_GPIO_Port GPIOA
//#define SWO_Pin GPIO_PIN_3
//#define SWO_GPIO_Port GPIOB
//#define D8CLK_Pin GPIO_PIN_4
//#define D8CLK_GPIO_Port GPIOB
#define RCLK_Pin GPIO_PIN_5
#define RCLK_GPIO_Port GPIOB
#define D4_Pin GPIO_PIN_6
#define D4_GPIO_Port GPIOB

void MFShield_GPIO_Init(void);

void Led_Blink(uint32_t current_tick, uint32_t wait);
void Knight_Rider(uint32_t current_tick, uint32_t wait);
void Write_ASCII_D4(uint8_t letter, uint8_t Digit,const uint8_t *Data);
void Write_D4_FSM(uint32_t current_tick, uint32_t wait, uint8_t *Msg );
uint8_t Get_Buttons(uint32_t current_tick, uint32_t wait);
uint32_t Sec_Count_FSM(uint32_t current_tick,uint32_t wait);
uint8_t* itoa(uint32_t value, uint8_t* buffer, uint8_t base);
void swap(uint8_t *x, uint8_t *y);
uint8_t* reverse(uint8_t *buffer, uint32_t i, uint32_t j);
void process_string(uint8_t *buffer);
extern int	abs (int);


#endif /* INC_APP_MFSHIELD_H_ */
