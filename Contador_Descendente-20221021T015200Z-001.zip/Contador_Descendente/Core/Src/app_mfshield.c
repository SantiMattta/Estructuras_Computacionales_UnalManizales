/*
 * app_mfshield.c
 *
 *  Created on: Jun 15, 2022
 *      Author: gosor
 */

#include "app_mfshield.h"

const uint8_t seven_seg_digits_decode_abcdefg[75]= {
		/*  0     1     2     3     4     5     6     7     8     9     :     ;     */
		0x7E, 0x30, 0x6D, 0x79, 0x33, 0x5B, 0x5F, 0x70, 0x7F, 0x7B, 0x40, 0x20,
		/*  <     =     >     ?     @     A     B     C     D     E     F     G     */
		0x10, 0x00, 0x04, 0x02, 0x01, 0x77, 0x1F, 0x4E, 0x3D, 0x4F, 0x47, 0x5E,
		/*  H     I     J     K     L     M     N     O     P     Q     R     S     */
		0x37, 0x06, 0x3C, 0x57, 0x0E, 0x55, 0x15, 0x1D, 0x67, 0x73, 0x05, 0x5B,
		/*  T     U     V     W     X     Y     Z     [     \     ]     ^     _     */
		0x0F, 0x3E, 0x1C, 0x5C, 0x13, 0x3B, 0x6D, 0x02, 0x04, 0x08, 0x10, 0x20,
		/*  `     a     b     c     d     e     f     g     h     i     j     k     */
		0x40, 0x77, 0x1F, 0x4E, 0x3D, 0x4F, 0x47, 0x5E, 0x37, 0x06, 0x3C, 0x57,
		/*  l     m     n     o     p     q     r     s     t     u     v     w     */
		0x0E, 0x55, 0x15, 0x1D, 0x67, 0x73, 0x05, 0x5B, 0x0F, 0x3E, 0x1C, 0x5C,
		/*  x     y     z     */
		0x13, 0x3B, 0x6D
};



/**
 * @brief GPIO Initialization Function
 * @param None
 * @retval None
 */
void MFShield_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOA, D1_Pin|D2_Pin|D3_Pin|SRCLK_Pin
			|SER_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOB, RCLK_Pin|D4_Pin, GPIO_PIN_RESET);



	/*Configure GPIO pins : S1_Pin S2_Pin */
	GPIO_InitStruct.Pin = S1_Pin|S2_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*Configure GPIO pins : D1_Pin D2_Pin D3_Pin  */
	GPIO_InitStruct.Pin = D1_Pin|D2_Pin|D3_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
	/*Configure GPIO pins :  SRCLK_Pin
	                           SER_Pin */
		GPIO_InitStruct.Pin = SRCLK_Pin | SER_Pin;
		GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*Configure GPIO pin : S3_Pin */
	GPIO_InitStruct.Pin = S3_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	HAL_GPIO_Init(S3_GPIO_Port, &GPIO_InitStruct);

	/*Configure GPIO pins :  RCLK_Pin D4_Pin */
	GPIO_InitStruct.Pin = D4_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	/*Configure GPIO pins :  RCLK_Pin  */
		GPIO_InitStruct.Pin = RCLK_Pin;
		GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
		HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);


}

void Led_Blink(uint32_t current_tick, uint32_t wait)
{
	static uint32_t  last_tick = 0;

	if (  current_tick - last_tick > wait){
		HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_6);
		HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7);

		last_tick = current_tick;
	}
}

void Knight_Rider(uint32_t current_tick, uint32_t wait)
{
	static uint32_t  last_tick = 0;
	static uint32_t state = 0, next_state = 0;

	if (  current_tick - last_tick > wait){
		//		if (state == 4){
		//			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_SET);
		//			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
		//			next_state = state+1;
		//		}
		//		if (state == 5){
		//			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
		//			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);
		//			next_state = state+1;
		//		}
		//		if (state == 6){
		//			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_SET);
		//			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET);
		//			next_state = state+1;
		//		}
		//		if (state == 7){
		//			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_SET);
		//			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
		//			next_state = state+1;
		//		}
		//		if (state == 8){
		//			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
		//			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET);
		//			next_state = state+1;
		//		}
		//		if (state == 9){
		//			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_SET);
		//			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);
		//			next_state = 4;
		//		}
		if (state == 0){
			HAL_GPIO_WritePin(D1_GPIO_Port, D1_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(D2_GPIO_Port, D2_Pin, GPIO_PIN_SET);
			next_state = state+1;
		}
		if (state == 1){
			HAL_GPIO_WritePin(D2_GPIO_Port, D2_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(D1_GPIO_Port, D1_Pin, GPIO_PIN_SET);
			next_state = state+1;
		}
		if (state == 2){
			HAL_GPIO_WritePin(D3_GPIO_Port, D3_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(D2_GPIO_Port, D2_Pin, GPIO_PIN_SET);
			next_state = state+1;
		}
		if (state == 3){
			HAL_GPIO_WritePin(D4_GPIO_Port, D4_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(D3_GPIO_Port, D3_Pin, GPIO_PIN_SET);
			next_state = state+1;
		}
		if (state == 4){
			HAL_GPIO_WritePin(D3_GPIO_Port, D3_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(D4_GPIO_Port, D4_Pin, GPIO_PIN_SET);
			next_state = state+1;
		}
		if (state == 5){
			HAL_GPIO_WritePin(D2_GPIO_Port, D2_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(D3_GPIO_Port, D3_Pin, GPIO_PIN_SET);
			next_state = 0;
		}

		state = next_state;
		last_tick = current_tick;
	}
}

void Write_ASCII_D4( uint8_t letter, uint8_t Digit,const uint8_t *Data ){

	//	static uint32_t  last_tick = 0;
	//	static uint32_t state = 0, next_state = 4;
	//	static uint8_t letter = 0;

	//	if (  current_tick - last_tick > wait){

	//  RCLK (PB5) -
	HAL_GPIO_WritePin(RCLK_GPIO_Port, RCLK_Pin, GPIO_PIN_RESET);

	// SRCLK (PA8) - 16 clock cycles
	HAL_GPIO_WritePin(SRCLK_GPIO_Port, SRCLK_Pin, GPIO_PIN_RESET);
	// Dot is set to turn it off
	HAL_GPIO_WritePin(SER_GPIO_Port, SER_Pin,GPIO_PIN_SET);
	HAL_GPIO_TogglePin(SRCLK_GPIO_Port, SRCLK_Pin);
	HAL_GPIO_TogglePin(SRCLK_GPIO_Port, SRCLK_Pin);
	for (int i = 0; i < 7; i++){
		// SER (PA9) - set
		HAL_GPIO_WritePin(SER_GPIO_Port, SER_Pin,~(Data[letter]>>i)&(1));
		HAL_GPIO_TogglePin(SRCLK_GPIO_Port, SRCLK_Pin);
		HAL_GPIO_TogglePin(SRCLK_GPIO_Port, SRCLK_Pin);
	}

	// All the displays are enable
	HAL_GPIO_WritePin(SER_GPIO_Port, SER_Pin,GPIO_PIN_RESET);
	for (int i = 0; i < 8; i++){
		if (i == Digit+3){
			HAL_GPIO_WritePin(SER_GPIO_Port, SER_Pin,GPIO_PIN_SET);
		}else{
			HAL_GPIO_WritePin(SER_GPIO_Port, SER_Pin,GPIO_PIN_RESET);
		}
		HAL_GPIO_TogglePin(SRCLK_GPIO_Port, SRCLK_Pin);
		HAL_GPIO_TogglePin(SRCLK_GPIO_Port, SRCLK_Pin);
	};
	//  RCLK (PB5) -
	HAL_GPIO_WritePin(RCLK_GPIO_Port, RCLK_Pin, GPIO_PIN_SET);
	//		letter++;
	//		if (letter > 74)
	//			letter = 0;
	//		last_tick = current_tick;
	//	}
}

void Write_D4_FSM(uint32_t current_tick, uint32_t wait, uint8_t *Msg)
{
	static uint32_t  last_tick = 0;
	static uint32_t state = 0, next_state = 0;

	static uint8_t i = 0;


	if (  current_tick - last_tick > wait){
		if (state == 0){
			Write_ASCII_D4((Msg[i]- 0x30), 4, seven_seg_digits_decode_abcdefg);
			next_state = state+1;
		}
		if (state == 1){
			Write_ASCII_D4((Msg[i+1]- 0x30), 3, seven_seg_digits_decode_abcdefg);
			next_state = state+1;
		}
		if (state == 2){
			Write_ASCII_D4(Msg[i+2]- 0x30, 2, seven_seg_digits_decode_abcdefg);
			next_state = state+1;
		}
		if (state == 3){
			Write_ASCII_D4(Msg[i+3]- 0x30, 1, seven_seg_digits_decode_abcdefg);
			next_state = 0;
		}
		state = next_state;
		last_tick = current_tick;
	}
}

uint8_t Get_Buttons(uint32_t current_tick, uint32_t wait){
	static uint_fast8_t flags = 0;
	static uint32_t  last_tick = 0;


	if (  current_tick - last_tick > wait){
		flags = 0;
		flags = 1^HAL_GPIO_ReadPin(S1_GPIO_Port, S1_Pin);
		flags <<= 1;
		flags |= (1^HAL_GPIO_ReadPin(S2_GPIO_Port, S2_Pin));
		flags <<= 1;
		flags |= (1^HAL_GPIO_ReadPin(S3_GPIO_Port, S3_Pin));
		last_tick = current_tick;
	}
	return flags;
}

uint32_t Sec_Count_FSM(uint32_t current_tick,uint32_t wait)
{
	static uint32_t sec_count = 0;
	static uint32_t  last_tick = 0;

	if (  current_tick - last_tick > wait){
		sec_count++;
		last_tick = current_tick;
	}

	return sec_count;
}

uint8_t* itoa(uint32_t value, uint8_t* buffer, uint8_t base)
{
	// invalid input
	if (base < 2 || base > 32) {
		return 0;
	}

	// consider the absolute value of the number
	int n = abs((int)value);

	int i = 0;
	while (n)
	{
		int r = n % base;

		if (r >= 10) {
			buffer[i++] = 65 + (r - 10);
		}
		else {
			buffer[i++] = 48 + r;
		}

		n = n / base;
	}

	// if the number is 0
	if (i == 0) {
		buffer[i++] = '0';
	}

	// If the base is 10 and the value is negative, the resulting string
	// is preceded with a minus sign (-)
	// With any other base, value is always considered unsigned
	if (value < 0 && base == 10) {
		buffer[i++] = '-';
	}

	buffer[i] = '\0'; // null terminate string

	// reverse the string and return it
	return reverse(buffer, 0, i - 1);
}

void swap(uint8_t *x, uint8_t *y) {
	uint8_t t = *x; *x = *y; *y = t;
}

// Function to reverse `buffer[i…j]`
uint8_t* reverse(uint8_t *buffer, uint32_t i, uint32_t j)
{
	while (i < j) {
		swap(&buffer[i++], &buffer[j--]);
	}

	return buffer;
}

void process_string(uint8_t *buffer){
	uint8_t i = 0;
	while (i<4){
		if (buffer[i] == '\0'){
			break;
		}
		i++;
	}
	if (i<4){
		for (int j=0;j<=i;j++){
			buffer[4-j]=buffer[i-j];
		}
		for (int j=0;j<4-i;j++){
					buffer[j]='=';
				}
	}

}
